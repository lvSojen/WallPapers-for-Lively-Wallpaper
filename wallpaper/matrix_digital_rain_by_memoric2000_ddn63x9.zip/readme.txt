The Matrix Has You...

"Matrix Digital Rain" using HTML5 Canvas & JavaScript.

Settings Explanation:
- Background Image -
It lists all .jpg & .png images that the folder "backgrounds" contains.
Choosing one will serve as a background for the canvas.
To see the "backgrounds" folder & to add images to it, right-click the wallpaper & choose "Show on Disk".
- Display Image? -
If checked, the selected image will be used.
Otherwise only the "Background Color" (see below) will be visible.
- Background Color -
The canvas' backgound color.
In can be used on its own, or in combination with a Backgound Image.
- Canvas Corners -
The curvature of the canvas' corners.
- Canvas Opacity -
The lower the value, the more transparent the canvas will be.
- Canvas Margin -
The width of the margin around the canvas.
- Font Size -
The size of the Rain's characters.
- Rain Speed -
The lower the value, the faster the Rain drops.
- Rain Color -
The color of the Rain's characters.
- Rain Fading / Trail Length -
The lower the value, the fastest the Rain fades / the shorter the trail's length.
- Rain Shadow (Glow) Color -
The color of the Rain characters' shadow (glow).
- Shadow (Glow) Diffusion -
The higher the value, the more the shadow (glow) will be diffused around the characters.
- Restore Defaults -
Restore all settings to their default values.

Credits:
Inspired by the "Matrix rain animation" found at "http://thecodeplayer.com/walkthrough/matrix-rain-animation-html5-canvas-javascript".
"Matrix Code NFI v1.0" font © "http://www.norfok.com".
"The Matrix" & "Matrix Digital Rain" © Warner Bros.
"Windows 10" logo © Microsoft.

This is a "Fan Art" non-commercial project.
If you are the copyright holder of any of the included material & you object to the inclusion of said material,
please contact me at "https://www.deviantart.com/memoric2000".

There is no spoon...