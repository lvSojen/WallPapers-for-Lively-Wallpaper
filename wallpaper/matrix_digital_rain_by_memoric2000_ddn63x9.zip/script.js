//////////////////////////////////////////////////

var loading = true;
var settings = [];
// drops array, one element per column
var drops = [];
// number of columns
var columns;
// string of characters
var alphabet = "abcdefghijklmnopqrstuvwxyz0123456789";
// convert the string into an array of single characters
var characters = alphabet.split("");

var canvas = document.getElementById('canvas');
var ctx = canvas.getContext('2d');
var canvasTimer;

//////////////////////////////////////////////////

function livelyPropertyListener(name, value) {

  if (name == "background_image") {
    settings[name] = value.replace('\\', '/')
  } else {
    settings[name] = value
  }
//  alert(name + ": " + settings[name]);

  if (name == "shadow_blur") {
    loading = false
  }

  if (!loading) {
    prepareCanvas()
  }
}

//////////////////////////////////////////////////

function prepareCanvas() {
  if (canvasTimer) {
    clearInterval(canvasTimer)
  }

  document.body.style.backgroundColor = settings['background_color'];
  if (settings['display_image'] == true) {
    document.getElementById('bg_image').classList.add('bg_image');
    document.getElementById('bg_image').style.backgroundImage = "url(" + settings['background_image'] + ")"
  } else {
    document.getElementById('bg_image').classList.remove('bg_image')
  }
  canvas.style.opacity = settings['canvas_opacity'] / 10;
  canvas.style.borderRadius = settings['canvas_corners'] + "px";

  // make the canvas full screen
  canvas.height = window.innerHeight - (settings['canvas_margin'] * 5);
  canvas.width = window.innerWidth - (settings['canvas_margin'] * 5);

  columns = (canvas.width) / settings['font_size'];

  // x = X coordinate, drop[x] = Y coordinate
  for (var x = 0; x < columns; x++) {
    drops[x] = - Math.floor(Math.random() * 100)
  }

  canvasTimer = setInterval(drawCanvas, settings['speed'])
}

//////////////////////////////////////////////////

function drawCanvas() {
  // set a transparent canvas backgound so trails are visible
  ctx.fillStyle = settings['background_color'] + parseInt(settings['text_fade'], 16);
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  // font
  ctx.font = settings['font_size'] + "px matrixfont";

  // loop drops
  for (var i = 0; i < drops.length; i++) {
    // character background to eliminate ghosting
    ctx.fillStyle = settings['background_color'] + parseInt(settings['text_fade'], 16);
    ctx.fillRect(i * settings['font_size'], drops[i] * settings['font_size'], settings['font_size'], settings['font_size']);
    // a random character to print
    var text = characters[Math.floor(Math.random() * characters.length)];
    // set character's glow (shadow)
    ctx.shadowColor = settings['shadow_color'];
    ctx.shadowBlur = settings['shadow_blur'];
    ctx.lineWidth = 1;
    // print character's glow
    ctx.strokeText(text, i * settings['font_size'], drops[i] * settings['font_size']);
    ctx.shadowBlur = 0;
    // print character
    ctx.fillStyle = settings['text_color'];
    ctx.fillText(text, i * settings['font_size'], drops[i] * settings['font_size']);

    // increment Y coordinate
    drops[i]++;

    // send the drop back to the top if:
    // it is outside the screen's boundaries
    // &
    // a random number is greater than some value (to add randomness to the drops' positions on the Y axis)
    if (drops[i] * settings['font_size'] > canvas.height && Math.random() > 0.975) {
      drops[i] = 0
    }
  }
}

//////////////////////////////////////////////////

function randomInt(min, max) {
  min = Math.ceil(min);
  max = Math.floor(max);
  return Math.floor(Math.random() * (max - min + 1)) + min
}

//////////////////////////////////////////////////